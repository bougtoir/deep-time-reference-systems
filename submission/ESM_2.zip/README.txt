Online Resource 2 for: Recoverability-aware records for spatial relations under incomplete reference-frame metadata
schema/dtrs_relation_record.schema.json - JSON Schema, version 1.1.0
examples/records/intact_<R>.json - intact records for representations A, B, BR, C, D, E
examples/records/S4_E.json, S9_E.json, S10_E.json - damaged records (silent handedness flip; CRS and witness lost; epoch-mislabelled values)
results/manuscript_values.csv - complete numerical registry; results/record_*.csv - benchmark outputs
Validate and decode with the dtrs.records package: https://github.com/bougtoir/deep-time-reference-systems

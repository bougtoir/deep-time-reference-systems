# Final reproducibility report

Audit date: 2026-10-17 (UTC)

## Environment

- Linux (Ubuntu), x86_64; Python venv at `.venv/`
- Pinned deps: numpy 2.2.6, pandas 2.3.3, matplotlib 3.10.9, scipy 1.15.3,
  PyYAML 6.0.2, python-docx 1.2.0, python-pptx 1.0.2, pytest 8.4.2

## Commands executed

1. `make reproduce` (= `make data` + `make manuscript` + `lint` + `test` +
   `verify-submission`):
   - verified 23 persisted raw source snapshots by size and SHA-256 (7 non-distributed
     local snapshots skipped by design);
   - ran `scripts/run_pipeline.py --config configs/default.yml` — regenerated
     `results/*.csv`, `figures/*.png`, `tables/*.csv`; all `manuscript_values.csv`
     entries identical to the committed registry;
   - rebuilt all docx/pdf/pptx and `submission/journal_of_geodesy_submission_FINAL.zip`;
   - `pytest`: 29 tests passed;
   - `verify_submission.py`: 26 manifested final files and ZIP integrity verified.
2. `make manuscript` (after the figure/table-numbering fixes): pipeline + builder rerun,
   36 s wall time; registry values again identical.
3. `pytest` rerun: 29 passed in ~1.1 s. `verify_submission.py` rerun: PASS.

## Failures / warnings

None. Runtime ~36–50 s per full pipeline. No network access required at build time
(raw inputs persisted and checksum-verified).
